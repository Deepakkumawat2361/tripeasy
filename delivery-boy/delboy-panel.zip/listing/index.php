<?php 
require "$_SERVER[DOCUMENT_ROOT]/connect.php";
$path = $_SERVER["DOCUMENT_ROOT"];
$desk_navbar = $mob_navbar= '';

$html='';

$sql=$connect->query("SELECT * FROM bookings");
while($res=$sql->fetch_object()){
	$html.='
			<div class="bg-white my-3">
                <div class="card rounded-4 border overflow-hidden">
                    <div class="card-header p-3 border-bottom">
                        <div class="d-flex justify-content-between">
                            <div class="d-flex gap-2">
                                <div><img src="img/s2.jpg" alt class="img-fluid rounded-pill ch-50" /></div>
                                <div>
                                    <h5 class="mb-1">Fresh Picks Mart ('.$res->temp_id.')</h5>
                                    <p class="text-muted my-0">Indistrail Area, Ludhiana</p>
                                    <div class="text-muted small">25 mins</div>
                                </div>
                            </div>
                            <div class="text-end">
                                <div class="badge bg-secondary mb-3 rounded-pill">Deliverd</div>
                                <div>
                                    <a href="#" class="text-decoration-none text-danger">View Store&nbsp;<i class="fa-solid fa-caret-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="d-flex align-items-center gap-2 mb-3">
                            <div><img src="img/veg.jpg" alt class="img-fluid ch-20" /></div>
                            <div class="text-muted">1&nbsp;x</div>
                            <div>Sweet Treat Pastries</div>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <div><img src="img/veg.jpg" alt class="img-fluid ch-20" /></div>
                            <div class="text-muted">1&nbsp;x</div>
                            <div>Fresh Harvest Apples</div>
                            <div class="text-muted d-block">Green</div>
                        </div>
                        <hr />
                        <a href="#" class="text-decoration-none link-dark">
                            <div class="d-flex justify-content-between">
                                <div class="text-muted">04 Mar 2024 at 2.22PM</div>
                                <div class="fw-bold">$101.00&nbsp;<i class="fa-solid fa-chevron-right text-muted"></i></div>
                            </div>
                        </a>
                        <hr />
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="text-muted">
                                Your rated&nbsp;&nbsp;<span class="badge bg-success rounded-pill">4&nbsp;<i class="fa-solid fa-star"></i></span>
                            </div>
                            <div>
                                <a href="#" class="btn btn-danger btn-sm rounded-pill small"><i class="fa-solid fa-arrow-rotate-right"></i>&nbsp;Reorder</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	';
}


$output = file_get_contents("index_tpl.html");

$out_arr["version"] = 1;
$out_arr["listing"] = $html;


foreach ($out_arr as $outKey => $outVal) {
    $output = str_replace("{" . $outKey . "}", $outVal, $output);
}
echo minifier($output);
function minifier($code)
{
	return $code;
    $search = ["/\>[^\S ]+/s", "/[^\S ]+\</s", "/(\s)+/s", "/<!--(.|\s)*?-->/"];
    $replace = [">", "<", '\\1'];
    $code = preg_replace($search, $replace, $code);
    return $code;
} ?>
 